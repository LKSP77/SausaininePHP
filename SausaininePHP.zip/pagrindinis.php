<!DOCTYPE html>


<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        
        <a href="registracija.php" style="font-size: 32px;">Registracija</a>
        <br><br>
        <a href="prisijungimas.php" style="font-size: 32px;">Prisijungimas</a>
    </body>
</html>
